./output/exe/bsp_timer.o: ..\\USER\\src\\bsp_timer.c \
  ..\USER\inc\bsp_timer.h ..\..\..\Libraries\inc\cw32l010.h \
  D:\keil5\ARM\CMSIS\5.8.0\CMSIS\Core\Include\core_cm0plus.h \
  D:\keil5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\keil5\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_version.h \
  D:\keil5\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\keil5\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_armclang.h \
  ..\..\..\Libraries\inc\cw32l010_btim.h \
  ..\..\..\Libraries\inc\system_cw32l010.h \
  ..\..\..\Libraries\inc\cw32l010.h ..\..\..\Libraries\inc\base_types.h \
  D:\keil5\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\keil5\ARM\ARMCLANG\Bin\..\include\string.h \
  D:\keil5\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\keil5\ARM\ARMCLANG\Bin\..\include\assert.h \
  ..\..\..\Libraries\inc\cw32l010_sysctrl.h
